using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro; 
using UnityEngine.SceneManagement; //Sahne K�t�phanesi

public class playerMovement : MonoBehaviour
{
    Rigidbody2D rgb; //Karaktere fizik kurallar� verdik
    Vector3 velocity; //H�z de�i�kenini tan�mlad�k
    public Animator animat�r;
    public TextMeshProUGUI playerScoreText; 
    public TextMeshProUGUI highScoreText; 

    public int score,highscore; //En y�ksek skor ve skor de�i�kenlerini tan�mlad�k

    float speedAmount = 5f;
    float jumpAmount = 4f;
    void Start()
    {
        score = PlayerPrefs.GetInt("score"); //Skor verisini tutan kod
        highscore = PlayerPrefs.GetInt("highscore"); //En y�ksek skor verisini tutan kod
        rgb = GetComponent<Rigidbody2D>();
    }
    void Update()
    {
        PlayerPrefs.SetInt("score", score); //Skor her artt���nda skoru yenileyen kod
        playerScoreText.text = score.ToString(); //Skoru ekrana yazd�ran kod
        highScoreText.text = highscore.ToString(); //En y�ksek skoru ekrana yazd�ran kod
        velocity = new Vector3(Input.GetAxis("Horizontal"), 0f); //Yataydaki h�z� tan�mlayan kod
        transform.position += velocity * speedAmount * Time.deltaTime; 
        animat�r.SetFloat("Speed", Mathf.Abs(Input.GetAxis("Horizontal"))); //Karakter sola gitti�inde h�z�n eksi olmas�n� engelleyen kod
        
        if (Input.GetKey("escape"))
        {
            highscore = 0;
            Application.Quit();
            Debug.Log("Oyundan ��kt�n�z!");
        }
        
        if (highscore < score) //En y�ksek skor, skordan d���kse
        {
            PlayerPrefs.SetInt("highscore", score); //Skoru en y�ksek skora tan�mla
            highScoreText.text = highscore.ToString();
        }

        if (Input.GetButtonDown("Jump") && Mathf.Approximately(rgb.velocity.y, 0))
        {
            SoundJump.PlaySound("playerJump"); //Z�plama sesini �a��ran kod
            rgb.AddForce(Vector3.up * jumpAmount, ForceMode2D.Impulse); //Z�plama tu�unu alg�layan kod
            animat�r.SetBool("IsJumping", true); //Z�plama animasyonunu ba�lat
        }

        if (animat�r.GetBool("IsJumping") && Mathf.Approximately(rgb.velocity.y, 0)) //Karakterin d��ey h�z� 0 olursa
        {
            animat�r.SetBool("IsJumping", false); //Z�plama animasyonunu durdur
        }

        if (Input.GetAxisRaw("Horizontal") == -1) //Karakter sola d�nerse
        {
            transform.rotation = Quaternion.Euler(0f, 180f, 0f); //Karakteri 180 derece d�nd�r
        }

        else if (Input.GetAxisRaw("Horizontal") == 1) //Karakter sa�a d�nerse
        {
            transform.rotation = Quaternion.Euler(0f, 0f, 0f); 
        }
    }
}