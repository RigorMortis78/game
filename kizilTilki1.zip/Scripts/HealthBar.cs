using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class HealthBar : MonoBehaviour
{
    public Health playerHealth;
    public Image totalhealthBar;
    public Image currenthealthBar;
    private void Start()
    {
        totalhealthBar.fillAmount = playerHealth.currentHealth / 10; //Ekrandaki dolu can barlar�n� g�sterir
    }
    private void Update()
    {
        currenthealthBar.fillAmount = playerHealth.currentHealth / 10; //Ekrandaki azalan can barlar�n� g�sterir
    }
}
