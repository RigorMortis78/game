using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundJump : MonoBehaviour
{
    public static AudioClip jumpSound;
    static AudioSource audioSrc;
    void Start()
    {
        jumpSound = Resources.Load<AudioClip>("playerJump"); //playerJump sesini coinSounda tan�mla
        audioSrc = GetComponent<AudioSource>();
    }
    void Update()
    {

    }
    public static void PlaySound(string clip)
    {
        switch (clip)
        {
            case "playerJump":
                audioSrc.PlayOneShot(jumpSound); //jumpSound'u ba�lat
                break;
        }
    }
}