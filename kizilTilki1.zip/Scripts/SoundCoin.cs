using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundCoin : MonoBehaviour
{
    public static AudioClip coinSound;
    static AudioSource audioSrc;
    void Start()
    {
        coinSound = Resources.Load<AudioClip>("playerCoin"); //playerCoin sesini coinSounda tan�mla
        audioSrc = GetComponent<AudioSource>();
    }
    void Update()
    {

    }
    public static void PlaySound(string clip)
    {
        switch (clip)
        {
            case "playerCoin":
                audioSrc.PlayOneShot(coinSound); //coinSound'u ba�lat
            break;
        }
    }
}
