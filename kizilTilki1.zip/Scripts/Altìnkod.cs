using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Altınkod : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag.Equals("Player")) //Karakter objeye değerse
        {
            SoundCoin.PlaySound("playerCoin"); //Altın sesini başlat
            playerMovement player = collision.gameObject.GetComponent<playerMovement>(); //playerMovement scriptini çağır
            player.score += 50; //Skoru 50 arttır
            gameObject.SetActive(false); //Objeyi yok et
        }
    }
}
