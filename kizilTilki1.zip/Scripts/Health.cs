using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class Health : MonoBehaviour
{
    Collision2D collision;
    public float startingHealth;
    public float currentHealth;
    public Animator anim;
    public void Awake()
    {
        currentHealth = startingHealth;
        anim = GetComponent<Animator>();
    }
    public void TakeDamage(float damage)
    {
        currentHealth = Mathf.Clamp(currentHealth - damage, 0, startingHealth); //Yeni can� hesapla

        if (currentHealth > 0) //Can s�f�rdan b�y�kse
        {
            SoundHurt.PlaySound("playerHurt"); //Karakter yaralanma sesini ba�lat
            anim.SetTrigger("hurt"); //Yaralnma animasyonunu ba�lat
        }
        if (currentHealth == 0) //Can s�f�r olursa
        {
            SceneManager.LoadScene("B�l�m1"); //Birinci b�l�m� y�kle
        }
    }
}