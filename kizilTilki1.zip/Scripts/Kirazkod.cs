using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Kirazkod : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag.Equals("Player")) //Karakter objeye de�erse
        {
            playerMovement player = collision.gameObject.GetComponent<playerMovement>(); //playerMovement scriptini �a��r
            player.score += 10; //Skoru 10 artt�r
            gameObject.SetActive(false); //Objeyi yok et
        }
    }
}
