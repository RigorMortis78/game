using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Merdivenkod : MonoBehaviour
{
    public Animator anima;
    public float speed;
    void OnTriggerStay2D(Collider2D other) //Karakter merdivenle temase ge�ince
    {
        if (other.tag == "Player" && Input.GetKey(KeyCode.UpArrow)) //Karakter yukar� tu�una basarsa
        {
            other.GetComponent<Rigidbody2D>().velocity = new Vector2(0, speed); //Merdiven ��k�� h�z�n� tan�mla
            speed = 4f;
            anima.SetTrigger("climb"); //Merdiven animasyonunu ba�lat
        }
        else if (other.tag == "Player" && Input.GetKey(KeyCode.DownArrow))//Karakter a�a�� tu�una basarsa
        {
            other.GetComponent<Rigidbody2D>().velocity = new Vector2(0, -speed); //Merdiven ini� h�z�n� tan�mla
            speed = 4f;
            anima.SetTrigger("climb"); //Merdiven animasyonunu ba�lat
        }
        else
        {
            other.GetComponent<Rigidbody2D>().velocity = new Vector2(0, 0);
        }
    }
}