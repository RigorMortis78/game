using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ölüm : MonoBehaviour
{
    [SerializeField] Transform spawnPoint;
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag.Equals("Player")) //Karakter objeyle temasa geçerse
        {
            collision.transform.position = spawnPoint.position; //Bölüm başlangıç noktasına ışınla
        }
    }
}
