using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundDiamond : MonoBehaviour
{
    public static AudioClip diamondSound;
    static AudioSource audioSrc;
    void Start()
    {
        diamondSound = Resources.Load<AudioClip>("playerDiamond"); //playerDiamond sesini coinSounda tan�mla
        audioSrc = GetComponent<AudioSource>();
    }
    void Update()
    {

    }
    public static void PlaySound(string clip)
    {
        switch (clip)
        {
            case "playerDiamond":
                audioSrc.PlayOneShot(diamondSound); //diamondSound'u ba�lat
                break;
        }
    }
}