using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundHurt : MonoBehaviour
{
    public static AudioClip jumpSound, hurtSound;
    static AudioSource audioSrc;
    void Start()
    {
        hurtSound = Resources.Load<AudioClip>("playerHurt"); //playerHurt sesini coinSounda tan�mla
        audioSrc = GetComponent<AudioSource>();
    }
    void Update()
    {

    }
    public static void PlaySound(string clip)
    {
        switch (clip)
        {
            case "playerHurt":
                audioSrc.PlayOneShot(hurtSound); //hurtSound'u ba�lat
                break;
        }
    }
}