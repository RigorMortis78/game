using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class S�f�rlama : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.tag.Equals("Player")) //Karakter objeyle temasa ge�erse
        {
            playerMovement player = collision.gameObject.GetComponent<playerMovement>(); //playerMovement scriptini �a��r
            player.score = 0; //Skoru s�f�rla
            player.highscore = 0;
            gameObject.SetActive(false); //Objeyi yok et
        }
    }
}
