using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platformkod : MonoBehaviour
{
    public Transform firstPos, secondPos; //1. ve 2. pozisyonlar� tan�mla
    public float speed;

    Vector3 nextPos;

    private void Start()
    {
        nextPos = firstPos.position;
    }

    private void Update()
    {
        if (transform.position == firstPos.position) //Varolan pozisyon 1.pozisyondaysa 
        {
            nextPos = secondPos.position; //2.pozisyona ilerle
        }

        if (transform.position == secondPos.position) //Varolan pozisyon 2.pozisyondaysa 
        {
            nextPos = firstPos.position; //1.pozisyona ilerle
        }

        transform.position = Vector3.MoveTowards(transform.position, nextPos, speed * Time.deltaTime); //2 pozisyon aras� h�z� ayarla
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawLine(firstPos.position, secondPos.position);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.transform.tag == "Player") //Karakter objeyle temasa ge�erse
        {
            collision.collider.transform.SetParent(transform); //Karakterin konumunu de�i�tirir
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.transform.tag == "Player") //Karakter objeyle temasa ge�erse
        {
            collision.collider.transform.SetParent(null); //Karakterin konumunu korur
        }
    }
}
